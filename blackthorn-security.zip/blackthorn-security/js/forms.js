(function(){
var C=window.BLACKTHORN_CONFIG||{};
var EM=/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/,PH=/^\+?[\d\s()\-]{7,20}$/;
function err(f,msg){var p=f.parentNode.querySelector('.err');f.setAttribute('aria-invalid',msg?'true':'false');if(msg)f.setAttribute('aria-describedby',p.id);else f.removeAttribute('aria-describedby');p.textContent=msg||''}
function check(f){var v=(f.type==='checkbox'?f.checked:f.value.trim()),m='';
if(f.hasAttribute('data-req')&&!v)m=f.type==='checkbox'?'You must acknowledge the privacy notice to continue.':'This field is required.';
else if(v&&f.type==='email'&&!EM.test(v))m='Enter a valid email address, for example name@example.com.';
else if(v&&f.type==='tel'&&!PH.test(v))m='Enter a valid telephone number, for example 082 123 4567.';
else if(v&&f.type==='number'&&(+v<1||+v>500))m='Enter a number between 1 and 500.';
err(f,m);return !m}
function status(el,cls,msg){el.className='status '+cls;el.textContent=msg}
document.querySelectorAll('form[data-form]').forEach(function(form){
var st=form.querySelector('.status'),btn=form.querySelector('button[type=submit]'),busy=false;
form.noValidate=true;
form.querySelectorAll('input,select,textarea').forEach(function(f){f.addEventListener('blur',function(){if(f.hasAttribute('data-req')||f.value)check(f)})});
form.addEventListener('submit',function(e){e.preventDefault();if(busy)return;
var bad=null;form.querySelectorAll('input,select,textarea').forEach(function(f){if(!check(f)&&!bad)bad=f});
if(bad){status(st,'bad','Please correct the highlighted fields and submit again.');bad.focus();return}
if(form.querySelector('.hp input').value){status(st,'bad','Your enquiry could not be sent. Please try again.');return}
if(!C.formEndpoint){status(st,'bad','Your enquiry has not been sent. Online submission is not configured yet.'+(C.email||C.phone?' Please contact us directly using the details on the Contact page.':' Please try again later.'));return}
var data={};new FormData(form).forEach(function(v,k){if(k!=='website')data[k]=v});data.form=form.getAttribute('data-form');
busy=true;btn.disabled=true;var lbl=btn.textContent;btn.textContent='Sending…';status(st,'load','Sending your enquiry…');
fetch(C.formEndpoint,{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify(data)})
.then(function(r){if(!r.ok)throw new Error('http '+r.status);form.reset();status(st,'ok','Thank you. Your enquiry has been received and will be reviewed.');st.focus()})
.catch(function(){status(st,'bad','Your enquiry could not be sent. Check your connection and try again'+(C.email?', or email '+C.email+'.':'.'))})
.then(function(){busy=false;btn.disabled=false;btn.textContent=lbl})});});
})();
