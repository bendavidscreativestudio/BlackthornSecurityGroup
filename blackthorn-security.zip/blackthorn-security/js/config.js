/* Business configuration. Leave a value empty ("") to keep it hidden on the live site. */
window.BLACKTHORN_CONFIG = {
  formEndpoint: "",   // e.g. "https://formspree.io/f/xxxxxxx" (see README)
  email: "",          // official business email
  phone: "",          // business telephone, e.g. "+27 21 000 0000"
  whatsapp: "",       // international format, digits only, e.g. "27821234567"
  area: "",           // confirmed service area
  hours: "",          // confirmed business hours
  social: {}          // e.g. { linkedin: "https://...", facebook: "https://..." }
};
