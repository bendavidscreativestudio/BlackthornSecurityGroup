(function(){
var C=window.BLACKTHORN_CONFIG||{},any=false;
document.querySelectorAll('[data-year]').forEach(function(e){e.textContent=new Date().getFullYear()});
document.querySelectorAll('[data-contact]').forEach(function(li){var k=li.getAttribute('data-contact'),v=(C[k]||'').trim(),a=li.querySelector('.v');
if(!v){li.hidden=true;return}any=true;a.textContent=v;
if(k==='email'){a.href='mailto:'+v}else if(k==='phone'){a.href='tel:'+v.replace(/[^\d+]/g,'')}});
document.querySelectorAll('[data-empty]').forEach(function(e){e.hidden=any});
document.querySelectorAll('[data-contact-list]').forEach(function(e){e.hidden=!any});
var wa=/^\d{10,15}$/.test((C.whatsapp||'').replace(/\D/g,''))?C.whatsapp.replace(/\D/g,''):'';
document.querySelectorAll('[data-whatsapp]').forEach(function(a){if(!wa){a.hidden=true;return}
a.href='https://wa.me/'+wa+'?text='+encodeURIComponent('Hello Blackthorn Security Group, I would like to discuss a security requirement.');a.target='_blank';a.rel='noopener noreferrer'});
})();
