(function(){
var sb=document.getElementById('sidebar'),btn=document.getElementById('menuBtn'),bd=document.getElementById('backdrop'),col=document.getElementById('collapseBtn'),b=document.body;
if(!sb)return;var mq=window.matchMedia('(min-width:960px)');
function fo(){return Array.prototype.filter.call(sb.querySelectorAll('a[href],button'),function(e){return e.offsetParent!==null})}
function openD(){sb.classList.add('open');bd.hidden=false;b.classList.add('lock');btn.setAttribute('aria-expanded','true');sb.setAttribute('role','dialog');sb.setAttribute('aria-modal','true');sb.setAttribute('aria-label','Site navigation');var f=fo();if(f[0])f[0].focus()}
function closeD(ret){if(!sb.classList.contains('open'))return;sb.classList.remove('open');bd.hidden=true;b.classList.remove('lock');btn.setAttribute('aria-expanded','false');sb.removeAttribute('role');sb.removeAttribute('aria-modal');sb.removeAttribute('aria-label');if(ret!==false)btn.focus()}
if(btn){btn.addEventListener('click',openD);bd.addEventListener('click',function(){closeD()});
sb.addEventListener('click',function(e){if(e.target.closest('a'))closeD(false)});}
document.addEventListener('keydown',function(e){if(!sb.classList.contains('open'))return;
if(e.key==='Escape'){closeD();return}
if(e.key==='Tab'){var f=fo();if(!f.length)return;var a=f[0],z=f[f.length-1];
if(e.shiftKey&&document.activeElement===a){e.preventDefault();z.focus()}else if(!e.shiftKey&&document.activeElement===z){e.preventDefault();a.focus()}}});
mq.addEventListener('change',function(m){if(m.matches)closeD(false)});
function setC(c){b.classList.toggle('collapsed',c);if(col){col.setAttribute('aria-expanded',String(!c));col.querySelector('.lbl').textContent=c?'Expand menu':'Collapse menu'}}
try{setC(localStorage.getItem('bt-collapsed')==='1')}catch(e){setC(false)}
if(col)col.addEventListener('click',function(){var c=!b.classList.contains('collapsed');setC(c);try{localStorage.setItem('bt-collapsed',c?'1':'0')}catch(e){}});
window.btCloseDrawer=closeD;})();
