# Blackthorn Security Group website

Static HTML, CSS and JavaScript. No build step, no dependencies.

## Run locally
Open `index.html`, or run `python3 -m http.server 8000` and visit http://localhost:8000.

## Deploy on GitHub Pages
1. Create a repository and upload the contents of this folder (so `index.html` is at the repository root).
2. Settings, Pages, Source: Deploy from a branch, branch `main`, folder `/ (root)`.
3. Your site appears at `https://<username>.github.io/<repository>/`.
4. Optional: add a custom domain under Pages, then replace `YOUR-DOMAIN` in `sitemap.xml` and `robots.txt`, and add canonical and `og:url` tags.

## Configure before launch (`js/config.js`)
Empty values stay hidden on the site.
- `formEndpoint`: a trusted form service URL (for example a Formspree form endpoint that accepts JSON POST). **Until it is set, both forms show an honest "not sent" message and never a false success.** GitHub Pages has no server, so a form service is required. Never put private API keys in this file.
- `email`, `phone`, `whatsapp` (digits only, international format, e.g. `27821234567`), `area`, `hours`.

## Business details still required before launch
Official email, telephone, WhatsApp number, confirmed service area and hours; PSiRA registration and company details (add only once verified); confirmation of which services are lawfully and practically available; reviewed Privacy Policy (POPIA) and Terms; licensed photography (none is included); production domain; form service account and spam settings.

## Notes
- Privacy and Terms pages are drafts and need legal review.
- Test checklist: all pages load, sidebar collapse, mobile drawer (Escape, backdrop, focus), form validation and failure states, keyboard navigation.
